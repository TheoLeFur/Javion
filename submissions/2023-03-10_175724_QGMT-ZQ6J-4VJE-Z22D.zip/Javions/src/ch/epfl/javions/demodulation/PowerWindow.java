package ch.epfl.javions.demodulation;

import ch.epfl.javions.Preconditions;

import java.io.IOException;
import java.io.InputStream;

public class PowerWindow {
    InputStream stream;
    int windowSize;
    int position = 0;
    final static int staticConstant = 65536;
    int[] tab1 = new int[staticConstant];
    int[] tab2 = new int[staticConstant];
    boolean isContained = true;
    int batchSize;
    PowerComputer calculator;


    public PowerWindow(InputStream stream, int windowSize) throws IOException {
        Preconditions.checkArgument((windowSize > 0) && (windowSize <= staticConstant));
        this.stream = stream;
        this.windowSize = windowSize;
        this.calculator = new PowerComputer(stream, staticConstant);
        batchSize = calculator.readBatch(tab1);
    }

    public int size() {
        return windowSize;
    }

    public long position() {
        return position;
    }

    public boolean isFull() {
        if (batchSize - position - windowSize < 0) {
            return false;
        } else {
            return true;
        }
    }

    public int get(int i) {
        if(!((i >= 0) && (windowSize > i))) {
            throw new IndexOutOfBoundsException();
        }
        if (isContained) {
            return tab1[i];
        } else {
            if (staticConstant - (position % staticConstant) <= i) {
                return tab1[i];
            } else {
                return tab2[i - staticConstant];
            }
        }
    }

    public void advance() throws IOException {

        position += 1;
        int[] tempTable;

        if (position % staticConstant == 0){
            tempTable = tab1.clone();
            tab1 = tab2.clone();
            tab2 = tempTable.clone();
            isContained = true;

        }

        if ((position + windowSize - 1) % staticConstant == 0){
            calculator.readBatch(tab2);
        }

    }

    public void advanceBy(int offset) throws IOException {
        Preconditions.checkArgument(offset >= 0);
        position += offset;
        int[] tempTab;

        if (isContained && ((position % staticConstant) + windowSize > staticConstant)) {
            isContained = false;
            tempTab = tab2.clone();
            tab2 = tab1.clone();
            tab1 = tempTab.clone();
        }

        if ((position % staticConstant) + windowSize  <= staticConstant && !isContained) {
            isContained = true;
        }
    }
}
