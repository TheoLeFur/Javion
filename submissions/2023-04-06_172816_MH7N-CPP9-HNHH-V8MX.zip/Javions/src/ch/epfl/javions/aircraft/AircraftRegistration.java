package ch.epfl.javions.aircraft;

import java.util.ArrayList;
import java.util.regex.Pattern;


public record AircraftRegistration(String string) {
    static Pattern allowedStrings = Pattern.compile("[A-Z0-9 .?/_+-]+");

    /**
     * @param string aircraft registration
     * @throws IllegalArgumentException if the given code is either empty or not a number, letter, or .?/_+-
     * @author Rudolf Yazbeck (SCIPER 360700)
     */
    public AircraftRegistration {
        if (!allowedStrings.matcher(string).matches()) {
            throw new IllegalArgumentException();
        }
    }
}